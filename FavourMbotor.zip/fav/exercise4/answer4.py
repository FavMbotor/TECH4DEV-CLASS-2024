SIZE = 7

for i in range(1, SIZE + 1):
   print(str(i) * i)