low = int(input("low? "))
high = int(input("high? "))
sum = 0

for i in range(low,high):
   sum += i

print("sum = " , sum)