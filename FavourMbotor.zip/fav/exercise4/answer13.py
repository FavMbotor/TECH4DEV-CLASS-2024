def printAverage():
  values = []

  while True:
    number = int(input("Type a number: "))
    if number < 0:
      break
    values.append(number)

  total = len(values)
  if(total > 0):
    print("Average was " , sum(values) / total)  



printAverage()