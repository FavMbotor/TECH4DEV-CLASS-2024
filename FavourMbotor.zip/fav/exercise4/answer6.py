import math

def area(radius):
   return math.pi * float(radius) ** 2



print(area(2.0))