sum = 0

while True:
  number = int(input("type in a number: "))
  if number == -1:
    break
  sum += number

print("sum = " , sum)