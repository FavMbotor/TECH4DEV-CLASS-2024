def smallestLargest():
    total_input = int(input("How many numbers do you want to enter? "))

    list = []
    for i in range(total_input):
      number = int(input("Number " + str(i + 1) + ": "))
      list.append(number)


    maximum = max(list)
    minimum = min(list)

    print("\nSmallest = ", minimum, "\nLargest = ", maximum)



smallestLargest()