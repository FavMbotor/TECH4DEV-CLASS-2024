for i in range(5):
    print('*' * 10 + '\n')