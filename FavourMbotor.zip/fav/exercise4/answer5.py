def pay(salaryPerHour, hoursPerDay):
   overtime = 0

   if hoursPerDay > 8:
      overtime = hoursPerDay - 8
      hoursPerDay = 8

   basePay = float(salaryPerHour) * float(hoursPerDay)
   overtimePay = 0

   if overtime > 0:
      overtimePay = overtime * salaryPerHour * 1.5
   
   return basePay + overtimePay



print(pay(5.50,6))
print(pay(4.00,11))