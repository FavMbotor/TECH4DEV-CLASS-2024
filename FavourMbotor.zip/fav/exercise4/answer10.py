def repl(str, rep):
    return str * rep

print(repl('hello', 3))
print(repl('hello', 0))
print(repl('hello', -1))