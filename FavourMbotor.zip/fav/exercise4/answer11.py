def printRange(start, end):
    isIncreasing = start < end
    stopper = -1
    if isIncreasing:
        stopper = 1
    
    step = -1
    if isIncreasing:
        step = 1
    

    for i in range(start, end + stopper,step):
        print(i)



printRange(2, 7)
print('\n')
printRange(19, 11)
print('\n')
printRange(5, 5)