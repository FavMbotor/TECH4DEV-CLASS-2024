import random

TARGET = 7
numberOfTries = 0

while True:
  numberOfTries += 1
  first_random_number = random.randint(1, 6)
  second_random_number = random.randint(1, 6)
  sum = first_random_number + second_random_number
  print(first_random_number, "+", second_random_number, "=", sum)
  if sum == TARGET:
    break


print("You won after", numberOfTries, "tries!")
