print('A \n')

for i in range(1, 7):
    print(i)

print('B \n')
for i in range(1, 7):
    print(i * 2)