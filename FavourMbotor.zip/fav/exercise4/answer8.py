sum = 0

while True:
  number = int(input("type in a number: "))
  sum += number
  if number == 0:
    break

print("sum = " , sum)