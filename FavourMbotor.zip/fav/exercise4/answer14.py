def numUnique(first, second, third):
  values = [first, second, third]

  print(len(set(values)))




numUnique(18,3,4)
numUnique(6,7,6)