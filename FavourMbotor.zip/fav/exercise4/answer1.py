for i in range(8):
    if(i == 0 or i == 7):
        print('+----+\n')
    else:
        if (i % 2 == 0):
            print('/    \\\n')
        else:
            print('\    /\n')