def printPrimeNumber(start, end):
    for i in range(start, end + 1):
        if isPrime(i):
            print(i)

def isPrime(number):
    for i in range(2, number):
        if number % i == 0:
            return False
    return True



printPrimeNumber(1, 100)