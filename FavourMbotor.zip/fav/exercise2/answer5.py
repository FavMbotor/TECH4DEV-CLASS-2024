def printMultiplicationTable(number, end = 12):
    for i in range(1, end + 1):
        print(number, " x ", i, " = ", number * i)



printMultiplicationTable(2)
print('\n')
printMultiplicationTable(12)