def countDigits(number):
    return len(str(number))


print(countDigits(1234))