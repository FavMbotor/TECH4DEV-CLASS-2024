arr = input('type in array - with space separating each number\n')
arr = arr.strip().split(' ')
arr = list(map(int, arr))

first_index = int(input('type in first index to swap\n'))
second_index = int(input('type in second index to swap\n\n\n'))

arr[first_index], arr[second_index] = arr[second_index], arr[first_index]

print(arr)