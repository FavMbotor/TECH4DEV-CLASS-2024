arr = input('type in array - with space separating each number\n')
arr = arr.strip().split(' ')
arr = list(map(int, arr))

value = int(input('type in value to find index for\n'))


index = -1

for i in range(len(arr)):
    if(arr[i] == value):
        index = i

print('\n Index is:')
print(index)

