arr = input('type in array - with space separating each number\n')
arr = arr.strip().split(' ')
arr = list(map(float, arr))


if(len(arr) == 1):
    print(True)
    exit(0)

for i in range(len(arr)):
    if(i != 0 and arr[i - 1] > arr[i]):
        print(False)
        exit()


print(True)
