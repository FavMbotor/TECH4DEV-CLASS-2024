arr = input('type in array - with space separating each number\n')
arr = arr.strip().split(' ')
arr = list(map(int, arr))

minimum = int(input('type in minimum value\n'))
maximum = int(input('type in maximum value\n'))

count = 0

for i in range(len(arr)):
    if(arr[i] >= minimum and arr[i] <= maximum):
        count += 1

print('\n')
print(count)