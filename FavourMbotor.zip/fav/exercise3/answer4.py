arr1 = input('type in array - with space separating each number\n')
arr1 = arr1.strip().split(' ')
arr1 = list(map(int, arr1))

arr2 = input('\ntype in another array - with space separating each number\n\n')
arr2 = arr2.strip().split(' ')
arr2 = list(map(int, arr2))


if(len(arr1) != len(arr2)): 
    print(False)
    exit()


for i in range(len(arr1)):
    if(arr1[i] >= arr2[i]):
        print(False)
        exit()

print(True)