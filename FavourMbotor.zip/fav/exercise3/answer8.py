arr = input('type in array - with space separating each number\n')
arr = arr.strip().split(' ')
arr = list(map(int, arr))

max_value = max(arr)
min_value = min(arr)

range_value = (max_value - min_value) + 1

for i in range(range_value):
    print(i + 1)
