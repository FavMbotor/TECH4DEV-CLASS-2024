arr1 = input('type in array - with space separating each number\n')
arr1 = arr1.strip().split(' ')
arr1 = list(map(int, arr1))

arr2 = input('\ntype in another array - with space separating each number\n')
arr2 = arr2.strip().split(' ')
arr2 = list(map(int, arr2))


new_array = arr1 + arr2


print(new_array)