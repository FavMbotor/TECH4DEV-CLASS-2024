arr = input('type in array - with space separating each number\n')
arr = arr.strip().split(' ')
arr = list(map(int, arr))

arr.reverse()
print(arr)
